function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6RX8x1YVw0J":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}


function ExecuteScript(strId)
{
  switch (strId)
  {
      case "5dtoJ8qwOmC":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

